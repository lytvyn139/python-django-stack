from django.db import models

# Create your models here.

class User(models.Model):
    firstName = models.CharField(max_length=255)
    lastName = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    gender = models.CharField(max_length=255, null = True)
    birthday = models.DateField(null = True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __repr__(self):
        return f"<User Object {self.firstName} {self.id}>"

class Message(models.Model):
    content = models.TextField()
    uploader = models.ForeignKey(User, related_name= "messages_uploaded", on_delete= models.CASCADE)
    likes = models.ManyToManyField(User, related_name = "liked_messages")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)



