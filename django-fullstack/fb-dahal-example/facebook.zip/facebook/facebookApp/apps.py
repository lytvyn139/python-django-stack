from django.apps import AppConfig


class FacebookappConfig(AppConfig):
    name = 'facebookApp'
