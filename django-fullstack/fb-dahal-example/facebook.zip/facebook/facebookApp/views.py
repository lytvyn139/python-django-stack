from django.shortcuts import render, HttpResponse, redirect
from .models import User, Message

# Create your views here.
def index(request):
    # print(User.objects.all())
   
    context = {
        'allusers': User.objects.all()
    }
    return render(request, "user.html", context)

def create(request):
    print("printing request.post which is the info from the form, below...")
    print(request.POST)
    print(request.POST['form_fname'])
    #classname.objects.create(fieldname = value for fieldname, etc;)
    newUser = User.objects.create(firstName = request.POST['form_fname'], lastName = request.POST['form_lname'], email = request.POST['form_email'])
    print(newUser)
    return redirect(f"/users/{newUser.id}")

def showuser(request, idUser):
    print(idUser)
    usertoshow = User.objects.get(id=idUser)
    # print(usertoshow.liked_messages.all())
    # usertoshow.delete()
    print(usertoshow)
    context = {
        'userobject': usertoshow,
        'allmessages': Message.objects.all()
    }
    return render(request, "showuser.html", context)

def assignMessage(request, idUser):
    print(request.POST)
    print(request.POST['selectedMessage'])
    # this_book = Book.objects.get(id=4)
    this_message = Message.objects.get(id= request.POST['selectedMessage'])
    this_user = User.objects.get(id= idUser)

    this_message.likes.add(this_user)
    return redirect(f"/users/{idUser}")

def deleteUser(request, idUser):
    # c = ClassName.objects.get(id=1)
    userToDelete = User.objects.get(id= idUser)
    # c.delete()
    userToDelete.delete()
    return redirect("/")
    
def editUser(request, idUser):
    
    context = {
        'userToEdit': User.objects.get(id= idUser)
    }
    return render(request, 'useredit.html', context)

def updateUser(request, idUser):
   
    print("*" * 50)
    print(request.POST)
    print(request.POST['fname'])
    # c = ClassName.objects.get(id=1)
    userToupdate = User.objects.get(id= idUser)
    # c.field_name = "some new value for field_name"
    userToupdate.firstName = request.POST['fname']
    userToupdate.lastName = request.POST['lname']
    # c.save()
    userToupdate.save()

    return redirect(f"/users/{idUser}")
    
