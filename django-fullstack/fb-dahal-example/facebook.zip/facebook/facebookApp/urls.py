from django.urls import path
from . import views

urlpatterns = [
    path("", views.index),
    path("createUser", views.create),
    path('users/<idUser>', views.showuser),
    path('assignMessageToUser/<idUser>', views.assignMessage),
    path("delete/<idUser>", views.deleteUser),
    path("edit/<idUser>", views.editUser),
    path("update/<idUser>", views.updateUser)
]